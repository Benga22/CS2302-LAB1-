# Course Name: CS2302
# Author: Olugbenga Iyiola ID:80638542
# Assignment 1, Number 2
# Instructor: Olac Fuentes
# T.A.: Nath Anindita
# Date of last modification: 02/08/2018
# Purpose of program: Using recursion to draw interesting ﬁgures

# Importing packages needed to calculate and plot the figures
import matplotlib.pyplot as plt
import numpy as np
import math

# This method is used to get coordinate of a circle
def circle(center, rad):
    n = int(2* rad * math.pi)   # Getting circumference of circle
    t = np.linspace(0,6.3, n)   # Creating n points ranging from 0 to 6.3
    x = center[0]+rad * np.sin(t)  # Getting x-axis
    y = center[1]+rad * np.cos(t)  # Getting y-axis
    return x, y

# This method is used to plot the circle and make recursive calls with new centers
def draw_circles (ax, n, center, radius, w):
    if n > 0:  # Method executes for n times
        x , y = circle(center, radius)  # Calling circle method with center and radius parameters
        ax.plot(x, y, color='k')  # Plotting the circle by joining coordinates with line
        center[0] = center[0] - (radius*(1-w))  # Shifting center of cirlce along x-axis
        draw_circles(ax, n - 1, center,radius*w, w)  # Recursively calling the method with new center


plt.close('all')
fig, ax = plt.subplots() # Creating subplots
draw_circles(ax,200,[100,0],100,0.95) # Calling the method
ax.set_aspect(1.0)
ax.axis('off')
plt.show()  # Displaying figure
fig.savefig('circles.png')
