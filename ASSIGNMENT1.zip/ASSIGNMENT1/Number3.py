# Course Name: CS2302
# Author: Olugbenga Iyiola ID:80638542
# Assignment 1, Number 3
# Instructor: Olac Fuentes
# T.A.: Nath Anindita
# Date of last modification: 02/08/2018
# Purpose of program: Using recursion to draw interesting ﬁgures

# Importing packages needed to calculate and plot the figures
import numpy as np
import matplotlib.pyplot as plt

#   This method is used to plot a binary tree by getting its coordinates
def draw_lines(ax,center,width):
     radius = width / 2  # Halving the tree width to get the radius
     treeArray = np.array([[center[0],center[1]],[center[0]-radius,center[1]-(2*radius)],[center[0],
                  center[1]],[center[0]+radius,center[1]-(2*radius)]])  # Getting tree coordinates
     ax.plot(treeArray[:,0], treeArray[:,1], color='k')  # Plotting tree

# The recursive method is used to get centers of tree
def draw_lines_loops(ax,center,n,width):
   radius=width/2
   if n>0: # Method executes n times
    draw_lines(ax,center,width)  # Calling method to draw tree
    left=[center[0]-(radius),center[1]-(2*radius)]  # left child center
    right=[center[0]+(radius),center[1]-(2*radius)]  # right child center

    draw_lines_loops(ax,left,n-1, width)  # Recursively calling method with left center
    draw_lines_loops(ax,right,n-1, width)  # Recursively calling method with right center

plt.close("all")
orig_size = 800
fig, ax = plt.subplots()
draw_lines_loops(ax,[0,0],5,orig_size)
ax.set_aspect(2)
ax.axis('off')
plt.show()  # Displaying figure
fig.savefig('squares.png')
